﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Net.NetworkInformation;

namespace ASP_Project
{
    public partial class Hall : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Buttonlk_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-6780A6R\SQLEXPRESS;Initial Catalog=msdb;Integrated Security=True";
            string sql = "INSERT INTO Hall(Name,Phone_Number,Aadhar_Number,Hall_Purpose,Hall_Type,Category) VALUES (@name,@phn_no,@Aadhar_no,@hall_purpose,@hall_type,@category)";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;
                    command.Parameters.AddWithValue("@name", name.Text.ToString());
                    command.Parameters.AddWithValue("@phn_no", phone.Text.ToString());
                    command.Parameters.AddWithValue("@Aadhar_no", aadhar.Text.ToString());
                    command.Parameters.AddWithValue("@hall_purpose", nop.Text.ToString());
                    command.Parameters.AddWithValue("@hall_type", HallType.);
                    command.Parameters.AddWithValue("@category", cattype.Text.ToString());
                    connection.Open();
                    command.ExecuteNonQuery();

                }
            }
            


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-6780A6R\SQLEXPRESS;Initial Catalog=msdb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT * FROM Hall", connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                GridView1.DataSource = dataTable;
                GridView1.DataBind();
            }
        }
    }
 }

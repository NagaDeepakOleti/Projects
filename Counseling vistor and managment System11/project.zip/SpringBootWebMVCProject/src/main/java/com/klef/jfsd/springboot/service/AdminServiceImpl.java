package com.klef.jfsd.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Employee;
import com.klef.jfsd.springboot.repository.AdminRespository;
import com.klef.jfsd.springboot.repository.EmployeeRepository;

@Service
public class AdminServiceImpl implements AdminService 
{
	@Autowired
	private AdminRespository adminRespository;
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Admin checkadminlogin(String uname, String pwd)
	{
		return adminRespository.checkadminlogin(uname, pwd);
		 
	}
	@Override
	public List<Employee> viewallemployees()
	{
		
		return (List<Employee>) employeeRepository.findAll();
	}
	@Override
	public void deleteemployee(int id)
	{
		
	 employeeRepository.deleteById(id);
		
	}
	@Override
	public Employee viewemployeebyid(int id) 
	{
		
		return employeeRepository.findById(id).get();
	}

}
